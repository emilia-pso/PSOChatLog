﻿This time, please download the PSOBB chat log tool.
Thank you very much.

This add-on is a chat log add-on created by ESC.
emilia @ tanuki is the modified version.
The content of the change is that the chat log can be saved.

ESC has given permission to distribute the modified version.
Regarding the modified version of the license, etc., we will comply with the notation of ESC.


ESC, Sega people, PSO people, Ephinea people,
Everyone involved in changing this software
Above all, I would like to thank everyone who plays with me.


--
この度は、PSOBBチャットログツールをダウンロードしていただき、
誠にありがとうございます。

このアドオンは、ESC様が作成されたチャットログアドオンを、
emilia@tanukiが、変更を加えたものになります。
変更の内容は、チャットログをセーブ出来る様にしたことです。

ESC様には変更版の配布について許可をいただいております。
変更版のライセンス等については、ESC様の表記に準拠いたします。


ESC様、セガの方々、PSOに関わる方々、Ephineaの方々、
このソフトの変更に関わった皆様
何よりも、一緒に遊んでくれる皆様に感謝申し上げます。
--

2021/08/16 emilia@tanuki
